#!/bin/sh
# Test prerm script
echo "Arguments: $*"
exit 0
