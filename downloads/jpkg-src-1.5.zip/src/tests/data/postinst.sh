#!/bin/sh
# Test postinst script.
echo "Arguments: $*"
exit 0
